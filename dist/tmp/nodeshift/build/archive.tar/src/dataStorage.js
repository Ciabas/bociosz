'use strict';
import fs from 'fs-sync'
import { MongoClient } from 'mongodb'

export const saveData = () => {

}

export const loadData = () => {
  fs.readJSON('data.json', (err, data) => {
    if (err) throw err;
    let parsedData = JSON.parse(data);
    console.log(data);
  });
}
